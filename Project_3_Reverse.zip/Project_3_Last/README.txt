LUlrich2@u.rochester.edu 
    Map.java,Edge.java,Node.java
    the Map class takes in input file and genrates two hashmaps one for id to node and anouther for the adjacensy list.
    than if we want directions to and from some where we call the directions method with also calls the short path methode. 
    the sortpath methode is an implementation of djkstras were we store all of the inforamtion in the node class insted of an array. 
    for the creation of the priority que we created the Hcomparetor class witch uses the Length methode wich is an implementation of haversine formula for distance.
    once we find the shortest path to every node from the start node we can find the end node and work backwards to creat an array list of ids that we need to get to for directions.
    then we wright them in to a scv file. once this is done we will show the map by creating a display and drawing lines based on the given positions of the nodes and there adjacensys.
    then if the node is on the sortest path to the destination we will culler the line red and increase its stroke size.  
    estimated runtime for nyc: 9 seconds
    estimated runtime for monroe: 1 second
    estimated runtime for ur: .2 seconds  